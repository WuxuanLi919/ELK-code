
! Copyright (C) 2013 J. K. Dewhurst, S. Sharma and E. K. U. Gross.
! This file is distributed under the terms of the GNU General Public License.
! See the file COPYING for license details.

subroutine genstress
use modmain
use modmpi
implicit none
! local variables
real(8) et0
! store original parameters
avec0(:,:)=avec(:,:)
tforce0=tforce
tforce=.false.
! restore original symmetries
call symmetry
! generate the strain tensors
call genstrain
! zero the stress tensor components
stress(:)=0.d0
! run the ground-state calculation
call gndstate
! check for stop signal
if (tstop) goto 10
! subsequent calculations will read in the potential from STATE.OUT
trdstate=.true.
! store the total energy
et0=engytot
! loop over strain tensors
do istrain=1,nstrain
  if (mp_mpi) then
    write(*,'("Info(genstress): strain tensor ",I1," of ",I1)') istrain,nstrain
  end if
! restore the lattice vectors
  avec(:,:)=avec0(:,:)
! run the ground-state calculation
  call gndstate
! check for stop signal
  if (tstop) goto 10
! compute the stress tensor component
  stress(istrain)=(engytot-et0)/deltast
end do
10 continue
! compute the maximum stress magnitude over all lattice vectors
stressmax=maxval(abs(stress(1:nstrain)))
! restore original parameters
istrain=0
avec(:,:)=avec0(:,:)
tforce=tforce0
end subroutine

