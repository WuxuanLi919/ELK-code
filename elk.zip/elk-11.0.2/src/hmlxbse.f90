
! Copyright (C) 2010 S. Sharma, J. K. Dewhurst and E. K. U. Gross.
! This file is distributed under the terms of the GNU General Public License.
! See the file COPYING for license details.

subroutine hmlxbse
use modmain
use modmpi
use modomp
implicit none
! local variables
integer ik2,nthd
call holdthd(nkptnr/np_mpi,nthd)
!$OMP PARALLEL DO DEFAULT(SHARED) &
!$OMP SCHEDULE(DYNAMIC) &
!$OMP NUM_THREADS(nthd)
do ik2=1,nkptnr
! distribute among MPI processes
  if (mod(ik2-1,np_mpi) /= lp_mpi) cycle
!$OMP CRITICAL(hmlxbse_)
  write(*,'("Info(hmlxbse): ",I0," of ",I0," k-points")') ik2,nkptnr
!$OMP END CRITICAL(hmlxbse_)
  call hmlxbsek(ik2)
end do
!$OMP END PARALLEL DO
call freethd(nthd)
end subroutine

